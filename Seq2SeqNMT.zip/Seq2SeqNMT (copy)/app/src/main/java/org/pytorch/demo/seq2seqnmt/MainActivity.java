// Copyright (c) 2020 Facebook, Inc. and its affiliates.
// All rights reserved.
//
// This source code is licensed under the BSD-style license found in the
// LICENSE file in the root directory of this source tree.

package org.pytorch.demo.seq2seqnmt;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;
import org.pytorch.IValue;
import org.pytorch.Module;
import org.pytorch.PyTorchAndroid;
import org.pytorch.Tensor;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;
import java.util.Objects;

import org.pytorch.Tensor;
import org.pytorch.torchvision.TensorImageUtils;

import static java.security.AccessController.getContext;

public class MainActivity extends AppCompatActivity implements Runnable{
    // to be consistent with the model inputs defined in seq2seq_nmt.py, based on
    // https://pytorch.org/tutorials/intermediate/seq2seq_translation_tutorial.html
    private static final int HIDDEN_SIZE = 2048;
    private static final int EOS_TOKEN = 2;
    private static final int MAX_LENGTH = 50;
    private static final String TAG = MainActivity.class.getName();
    private static final int CAMERA_PIC_REQUEST = 1001;
    private static final int PERMISSION_CODE = 1002;

    private Module mModuleEncoder;
    private Module mModuleDecoder;
    private Module mModuleGenerator;
    private Tensor mInputTensor;
    private LongBuffer mInputTensorBuffer;
    private LongBuffer mHiddenTensorBuffer;

    private EditText mEditText;
    private TextView mTextView;
    private Button mCaptionButton;
    private Button mCameraButton;
    private ImageView mivImage;
    private Uri mImageUri;
    private Bitmap inputImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCaptionButton = findViewById(R.id.btnCaption);
        mCameraButton = findViewById(R.id.btnCamera);
        mivImage = findViewById(R.id.ivImage);
        mTextView = findViewById(R.id.tvTo);

        mCaptionButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mCaptionButton.setEnabled(false);
                Thread thread = new Thread(MainActivity.this);
                thread.start();
            }
        });

        mCameraButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) ==
                            PackageManager.PERMISSION_DENIED ||
                            checkSelfPermission(Manifest.permission.CAMERA) ==
                                    PackageManager.PERMISSION_DENIED) {
                        String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};

                        requestPermissions(permission, PERMISSION_CODE);

                    } else {
                        openCamera();
                    }
                } else {
                    openCamera();
                }

            }
        });
    }

    private void showTranslationResult(String result) {
        mTextView.setText(result);
    }

    public void run() {
        final String result = generateCaption();
        runOnUiThread(() -> {
            showTranslationResult(result);
            mCaptionButton.setEnabled(true);
        });
    }

    private String translate(final String text) {
        if (mModuleEncoder == null) {
//            mModuleEncoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "optimized_encoder_150k.pth");
            mModuleEncoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "encoder.pt");
        }

        String json;
        JSONObject wrd2idx;
        JSONObject idx2wrd;
        try {
            InputStream is = getAssets().open("target_idx2wrd.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            json = new String(buffer, "UTF-8");
            idx2wrd = new JSONObject(json);

            is = getAssets().open("source_wrd2idx.json");
            size = is.available();
            buffer = new byte[size];
            is.read(buffer);
            is.close();

            json = new String(buffer, "UTF-8");
            wrd2idx = new JSONObject(json);
        } catch (JSONException | IOException e) {
            android.util.Log.e(TAG, "JSONException | IOException ", e);
            return null;
        }

        String french = text;
        long[] inputs =  new long [french.split(" ").length];
        try {
            for (int i = 0; i < french.split(" ").length; i++) {
                inputs[i] = wrd2idx.getLong(french.split(" ")[i]);
            }
        }
        catch (JSONException e) {
            android.util.Log.e(TAG, "JSONException ", e);
            return null;
        }

        final long[] inputShape = new long[]{1};
        final long[] hiddenShape = new long[]{1, 1, 256};
        final FloatBuffer hiddenTensorBuffer =
                Tensor.allocateFloatBuffer(1 * 1 * 256);
        Tensor hiddenTensor = Tensor.fromBlob(hiddenTensorBuffer, hiddenShape);

        final long[] outputsShape = new long[]{MAX_LENGTH, HIDDEN_SIZE};
        final FloatBuffer outputsTensorBuffer =
                Tensor.allocateFloatBuffer(MAX_LENGTH  * HIDDEN_SIZE);

        for (int i=0; i<inputs.length; i++) {
            LongBuffer inputTensorBuffer = Tensor.allocateLongBuffer(1);
            inputTensorBuffer.put(inputs[i]);
            Tensor inputTensor = Tensor.fromBlob(inputTensorBuffer, inputShape);
            final IValue[] outputTuple = mModuleEncoder.forward(IValue.from(inputTensor), IValue.from(hiddenTensor)).toTuple();
            final Tensor outputTensor = outputTuple[0].toTensor();
            outputsTensorBuffer.put(outputTensor.getDataAsFloatArray());
            hiddenTensor = outputTuple[1].toTensor();
        }

        Tensor outputsTensor = Tensor.fromBlob(outputsTensorBuffer, outputsShape);
        final long[] decoderInputShape = new long[]{1, 1};
        if (mModuleDecoder == null) {
//            mModuleDecoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "optimized_decoder_150k.pth");
            mModuleDecoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "decoder.pth");
            Log.d("DECODER","Decoder loaded succesfully.");
        }

        mInputTensorBuffer = Tensor.allocateLongBuffer(1);
        mInputTensorBuffer.put(1);
        mInputTensor = Tensor.fromBlob(mInputTensorBuffer, decoderInputShape);
        ArrayList<Integer> result = new ArrayList<>(MAX_LENGTH);
        for (int i=0; i<MAX_LENGTH; i++) {
            final IValue[] outputTuple = mModuleDecoder.forward(
                IValue.from(mInputTensor),
                IValue.from(hiddenTensor),
                IValue.from(outputsTensor)).toTuple();
            final Tensor decoderOutputTensor = outputTuple[0].toTensor();
            hiddenTensor = outputTuple[1].toTensor();
            float[] outputs = decoderOutputTensor.getDataAsFloatArray();
            int topIdx = 0;
            double topVal = -Double.MAX_VALUE;
            for (int j=0; j<outputs.length; j++) {
                if (outputs[j] > topVal) {
                    topVal = outputs[j];
                    topIdx = j;
                }
            }

            if (topIdx == EOS_TOKEN) break;

            result.add(topIdx);
            mInputTensorBuffer = Tensor.allocateLongBuffer(1);
            mInputTensorBuffer.put(topIdx);
            mInputTensor = Tensor.fromBlob(mInputTensorBuffer, decoderInputShape);
        }

        String english = "";
        try {
            for (int i = 0; i < result.size(); i++)
                english += " " + idx2wrd.getString("" + result.get(i));
        }
        catch (JSONException e) {
            android.util.Log.e(TAG, "JSONException ", e);
        }
        return english;
    }

    private String generateCaption() {
//        mModuleEncoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "encoder.pth");
//        mModuleDecoder = PyTorchAndroid.loadModuleFromAsset(getAssets(), "decoder.pth");
        mModuleGenerator = PyTorchAndroid.loadModuleFromAsset(getAssets(), "generator.pth");

        String json;
        JSONObject wrd2idx;
        JSONObject idx2wrd;
        try {
            InputStream is = getAssets().open("index2word.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            json = new String(buffer, "UTF-8");
            idx2wrd = new JSONObject(json);

            is = getAssets().open("word2index.json");
            size = is.available();
            buffer = new byte[size];
            is.read(buffer);
            is.close();

            json = new String(buffer, "UTF-8");
            wrd2idx = new JSONObject(json);
        } catch (JSONException | IOException e) {
            android.util.Log.e(TAG, "JSONException | IOException ", e);
            return null;
        }

        // preparing input tensor
        final Tensor inputTensor = TensorImageUtils.bitmapToFloat32Tensor(inputImage,
                TensorImageUtils.TORCHVISION_NORM_MEAN_RGB, TensorImageUtils.TORCHVISION_NORM_STD_RGB);

        // running the model
//        final Tensor featureTensor = mModuleGenerator.forward(IValue.from(inputTensor)).toTensor();
        final Tensor featureTensor = mModuleGenerator.forward(IValue.from(inputTensor)).toTensor();
        float[] result = featureTensor.getDataAsFloatArray();

        StringBuilder caption = new StringBuilder();
        try {
            for (float i : result) {
                if (i == 2.0) {
                    break;
                }
                caption.append(" ").append(idx2wrd.getString("" + Math.round(i)));
            }
        }
        catch (JSONException e) {
            android.util.Log.e(TAG, "JSONException ", e);
        }
        return caption.toString();


    }



    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        mImageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
//        Camera Intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);
        startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if (requestCode == CAMERA_PIC_REQUEST && resultCode == Activity.RESULT_OK) {

            Picasso.get().load(mImageUri).into(mivImage);

            try {
                InputStream inputStream = this.getContentResolver().openInputStream(mImageUri);
                inputImage = BitmapFactory.decodeStream(inputStream);
                inputImage = Bitmap.createScaledBitmap(inputImage, 80, 80, true);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }


    }


}